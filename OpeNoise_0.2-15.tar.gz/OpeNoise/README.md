# OpeNoise_R_Package

## Comando per il check del  package

```r:
devtools::check()
```

## Comando per la creazione della documentazione

```r:
devtools::document(roclets = c('rd', 'collate', 'namespace', 'vignette'))
```

## Comando per la creazione del package

```r:
devtools::build()
```

## Comando per la creazione del package come binario

```r:
devtools::build(binary = TRUE, args = c('--preclean'))
```

## Comando per l'installazione del package dalla shell

```bash:
R CMD INSTALL --preclean --no-multiarch --with-keep.source openoise_r_package
```
