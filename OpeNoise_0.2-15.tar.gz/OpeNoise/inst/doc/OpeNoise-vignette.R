## ---- echo=FALSE--------------------------------------------------------------
htmltools::img(src =  "hex-OpeNoise.png", 
               alt = 'logo', 
               style = 'position:absolute; top:0; right:0; padding:10px; width: 100px; height: 118px')

## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
knitr::opts_chunk$set(dev = "png", dev.args = list(type = "cairo-png"))

## -----------------------------------------------------------------------------
library(OpeNoise)

data("PTFA")

head(PTFA)[1:3, 1:6]


## -----------------------------------------------------------------------------
energetic.mean(PTFA$LAeq)

x <- energetic.mean(PTFA$LAeq)

RoundTo(x, 0.5)

## -----------------------------------------------------------------------------
energetic_w.mean(c(55.2, 88.6), c("03:22:52", "08:55:33"))

## -----------------------------------------------------------------------------
AcuPercentile(PTFA$LAeq)

RoundTo(AcuPercentile(PTFA$LAeq), 0.5)

## -----------------------------------------------------------------------------
HourlyEmean(PTFA, "LAeq", timeZone = "Europe/Rome")

## -----------------------------------------------------------------------------
hour <- 5
minute <- 25
second <- 50
deco.time(hour, minute, second)

## -----------------------------------------------------------------------------
HolidaysDate(2022)

## ---- warning=FALSE-----------------------------------------------------------
data("exampleHourlyData")

df_night <- avr.day.night(exampleHourlyData, variable = "leq", period = "night", 
              stat = "e_mean")

head(df_night, 5)

df_day <- avr.day.night(exampleHourlyData, variable = "leq", period = "day", 
              stat = "e_mean")

head(df_day, 5)

## -----------------------------------------------------------------------------
data("exampleHourlyData")

LdenCalculator(dataframe = exampleHourlyData, variable = "leq", type = "daily")

LdenCalculator(dataframe = exampleHourlyData, variable = "leq", type = "total")

## ---- warning=FALSE-----------------------------------------------------------
dbsum(x = 55, y = 33, operator = 1)
dbsum(x = c(55 , 66), y = c(45, 50), operator = 1)

dbsum(x = c(55 , 66), y = c(70, 68), operator = -1)

## ---- warning=FALSE-----------------------------------------------------------
SELcalc(x = 66.8, t = 938)

## ---- fig.show='hide'---------------------------------------------------------
PlotNoiseTimeHistory(df = PTFA, mp = "PTFA", y_lim = c(40, 60))

## ---- echo=FALSE--------------------------------------------------------------
knitr::include_graphics("plot_image/TH.png")

## ---- fig.show='hide'---------------------------------------------------------
PlotNoiseTHcompare(df = PTFA, 
                   variable = "LAeq", 
                   listvar = c("LZFmin.100",
                               "LZFmin.40.0"),
                   mp = "PTFA", 
                   runleq = FALSE)

## ---- echo=FALSE--------------------------------------------------------------
knitr::include_graphics("plot_image/TH_compare.png")

## ---- fig.show='hide'---------------------------------------------------------
PlotSpectrogram(PTFA, coLs = c(3:38), plot_title = "Spectrogram")

## ---- echo=FALSE--------------------------------------------------------------
knitr::include_graphics("plot_image/spectrogram.png")

## ---- fig.show='hide', warning=FALSE------------------------------------------
library(lubridate)

datasetI <- dataset_impulsive1
datasetH <- dfImpulsiveTrasform(datasetI)
datasetH$date <- ymd_hms(as.character(datasetH$date))

AcousticQuantilePlot(df = datasetH, Cols =c(3:38), Quantile =0.95,
                     TimeZone = "UTC")

## ---- echo=FALSE--------------------------------------------------------------
knitr::include_graphics("plot_image/AcousticQuantilePlot.png")

## ---- fig.show='hide', warning=FALSE------------------------------------------
search.tone(PTFA[, c(3:38)], statistic = energetic.mean, plot.tone = T)

## ---- echo=FALSE--------------------------------------------------------------
knitr::include_graphics("plot_image/search_tone.png")

## ---- warning=FALSE-----------------------------------------------------------
data("dataset_impulsive2")
results <- searchImpulse(dataset_impulsive2)
results$dfPeaks

## ---- echo=FALSE--------------------------------------------------------------
knitr::include_graphics("plot_image/ImpulsiveFinder.png")

## -----------------------------------------------------------------------------
data("dataset_impulsive2")
head(dataset_impulsive2, 3)[, 1:5]
dfT <- dfImpulsiveTrasform(dfImpulsive = dataset_impulsive2, 
                           statistic = energetic.mean)
head(dfT, 3)[, 1:5]

