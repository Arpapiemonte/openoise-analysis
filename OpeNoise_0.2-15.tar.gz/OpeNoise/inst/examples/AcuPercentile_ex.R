# Calculate reverse quantile of a vector of values

#data(PTFA)

AcuPercentile(PTFA$LAeq)
