#data(PTFA)
#data("markers")

ExtractIndexMark(filemarks = markers , dataset = PTFA, mp = "PTFA")
