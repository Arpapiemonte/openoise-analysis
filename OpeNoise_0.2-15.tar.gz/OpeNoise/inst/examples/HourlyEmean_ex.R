#data(PTFA)

HourlyEmean(df = PTFA, variable = "LAeq")
