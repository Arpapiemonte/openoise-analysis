#data("exampleHourlyData")

LdenCalculator(dataframe = exampleHourlyData, variable = "leq",
               type = "daily")

LdenCalculator(dataframe = exampleHourlyData, variable = "leq",
               type = "total")
