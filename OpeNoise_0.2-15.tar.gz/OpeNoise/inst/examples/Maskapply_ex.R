#data(PTFA)
#data(markers)

Maskapply(filemarks = markers, dataset = PTFA, mp = "PTFA")
