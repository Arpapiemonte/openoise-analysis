#data(P1FA)

PlotSpectrogram(df = P1FA, coLs = c(3:38) , plot_title = "Spettrogram LZFmin")
