#data("P1FA")

RoundTo(x = P1FA$LAeq, multiple = 0.5)
