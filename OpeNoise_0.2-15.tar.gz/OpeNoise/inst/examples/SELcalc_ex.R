# Calculate SEL (Single Event Level)

SELcalc(x = 66.8, t = 938)