# Calculate energetic sum or difference of values

dbsum(x = 55, y = 33, operator = 1)
dbsum(x = c(55 , 66), y = c(45, 50), operator = 1)

dbsum(x = c(55 , 66), y = c(70, 68), operator = -1)
