# Convert H:M:S to seconds
x = 5  # Hours
y = 25 # minutes
z = 50 # seconds

deco.time(x = x, y = y, z = z)
