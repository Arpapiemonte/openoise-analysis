#data("dataset_impulsive1")
#data("dataset_impulsive2")

dfImpulsiveTrasform(dfImpulsive = dataset_impulsive1,
                    statistic = energetic.mean)
