# Calculate energetic mean of vector's values of Leq
energetic.mean(c(55, 88, 66, 51, 70))
