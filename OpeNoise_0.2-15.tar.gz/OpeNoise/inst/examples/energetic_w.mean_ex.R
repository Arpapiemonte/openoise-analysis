# Calculate weight energetic mean
energetic_w.mean(x = c(55.0, 70.0) , t = c("03:55:22", "01:33:12"))
