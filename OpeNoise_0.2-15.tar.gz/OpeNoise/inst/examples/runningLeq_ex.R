#data("P1FA")

runningLeq(x = P1FA$LAeq)
