#data("dataset_impulsive1")
#data("dataset_impulsive2")

searchImpulse(df = dataset_impulsive1)
searchImpulse(df = dataset_impulsive2)
